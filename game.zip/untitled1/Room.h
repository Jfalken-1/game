//
// Created by Jacob on 1/21/2025.
//

#ifndef ROOM_H
#define ROOM_H
#include <iostream>
#include <string>
#include <vector>


class Room {
private:

public:

};

class Item {
private:
std::string name;

public:
Item(const std::string &itemName);
void display() const {
    std::cout << name << '\n';
}

};

class Chest {
private:
std::vector<Item> items;

public:
Chest(const std::vector<Item>& itemsInChest);

void showItems() {
    for (const auto& item : items) {
        item.display();
    }
}
};



#endif //ROOM_H
