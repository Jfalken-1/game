#include <iostream>
#include <vector>
#include "Player.h"
#include "Room.h"


int main() {
    std::string name;
    std::cout << "Chose your name" << std::endl;
    std::cin >> name;

    std::cout << "Greetings, " << name << '\n' << "Choose your class" << std::endl;
    std::cout << "1: Fighter" << '\n' << "2: Rogue" << '\n' << "3: mage" << '\n';
    int input;
    std::cin >> input;

    std::vector<Item> items;
    if (input == 1) {
        items.emplace_back("Sword");
        items.emplace_back("Shield");
        Player player (name, items);
        std::cout << "Starting items: " << '\n';
        player.displayInventory();
    } else if (input == 2) {
        items.emplace_back("bow");
        items.emplace_back("dagger");
        Player player (name, items);
        std::cout << "Starting items: " << '\n';
        player.displayInventory();
    } else if (input == 3) {
        items.emplace_back("staff");
        items.emplace_back("dagger");
        Player player (name, items);
        std::cout << "Starting items: " << '\n';
        player.displayInventory();
    } else {
        std::cout << "FUCK YOU";
    }


    return 0;
}
