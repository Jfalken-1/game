//
// Created by Jacob on 1/21/2025.
//

#include "Room.h"

Item::Item(const std::string& itemName) : name(itemName){}

Chest::Chest(const std::vector<Item> &itemsInChest) : items(itemsInChest){}

