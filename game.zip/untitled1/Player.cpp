//
// Created by Jacob on 1/21/2025.
//

#include <iostream>

#include "player.h"

void Player::displayStats() {
    std::cout << "Name: " << name << '\n' << "HP: " << hp << '\n' <<  "MP: " << mp << '\n' << "Gold: " << gold;
};

void Player::displayInventory() {
    for (const auto& items : inventory) {
        items.display();
    }
}

Player::Player(const std::string &playerName, const std::vector<Item>& playerInventory) : name(playerName), inventory(playerInventory) {}



