//
// Created by Jacob on 1/21/2025.
//

#ifndef TEST_H
#define TEST_H
#include <string>
#include <vector>
#include "Room.h"


class Player {
public:
void displayStats();
void displayInventory();
Player(const std::string& playerName, const std::vector<Item>& playerInventory);

private:
   std::string name;
   int hp = 100;
   int mp = 50;
   int gold = 0;
   std::vector<Item> inventory;
};



#endif //TEST_H
